1. 

  - Projektiin on toteutettu t�ll� hetkell� kaikki tarvittavat perusominaisuudet
  poislukien tiedoston lukeminen ja tallennus. T�m�n lis�ksi grafiikat ja itse
  pelin kulku t�ytyy tehd�, mutta ne on suhteellisen helppo rakentaa t�m�n hetkisen
  pohjan p��lle. AI:ta my�skin t�ytyy kehitt��.

2. K�ytt�ohje

  - Ohjelman voi ajaa, mutta t�m�nhetkinen ajaminen on hyvin rajallinen, mainista l�ytyy
  perus pelin aloitus tapahtuma joka tekstikonsoliin printataan, ja kommenttien sis�ll� on testi
  jolla n�kee miten korttien laillisuus ja liike testataan.
  - Ohjelma k�ynnistet��n mainissa
  - Kuten yll� selitin, testata kaikkia perusominaisuuksia t�ll� hetkell� ohjelmassa.

3. Aikataulu

  - vaikea sanoa, kun olen tehnyt niin hajanaisesti, mutta v�itt�isin 15-20 h
  - Osaan ohjelman osa-alueista on kulunut v�hemm�n aikaa kuin ajattelin, l�hinn�
  eniten aikaa on kulunut ohjelman kulkemisen j�sentelyyn ja optimaalisen 
  rakenteen l�yt�miseen.

4. Muuta

  - Ei varsinaisesti, ehk� pit�isi p�ivitt�� suunnitelmaa jotta lopputulos
  olisi selke�mpi.
  - Luultavasti tulen leikkaamaan suuren osan t�m�nhetkisist�
  luokista ja yhdistelem��n niit�, koska n�in usealle ei ole tarvetta. N�in on k�ynyt
  esim playermovelle. T�m�n lis�ksi yl�luokat ovat menneet kokonaan uusiksi, samoin
  osa k�skyist� ja niiden paikoista luokissa.